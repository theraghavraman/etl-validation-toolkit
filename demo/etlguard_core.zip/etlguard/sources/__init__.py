"""Shared browser-safe lineage package."""
